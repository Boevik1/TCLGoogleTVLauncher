package com.example.tvlauncher

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.Bitmap
import android.graphics.Canvas

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF1B1D25)
private val Accent = Color(0xFF8AB4F8)
private val Muted = Color(0xFFB7BBC7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Bg.toArgb()
        window.navigationBarColor = Bg.toArgb()
        setContent { LauncherApp() }
    }
}

data class TvApp(val label: String, val packageName: String, val icon: Drawable)

@Composable
private fun LauncherApp() {
    val context = LocalContext.current
    var selectedSection by remember { mutableStateOf("Главная") }
    var apps by remember { mutableStateOf(emptyList<TvApp>()) }

    fun loadApps() {
        val pm = context.packageManager
        val leanback = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val regular = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = LinkedHashMap<String, TvApp>()
        @Suppress("DEPRECATION")
        (pm.queryIntentActivities(leanback, PackageManager.MATCH_ALL) + pm.queryIntentActivities(regular, PackageManager.MATCH_ALL))
            .forEach { info ->
                val pkg = info.activityInfo.packageName
                if (pkg != context.packageName && !found.containsKey(pkg)) {
                    val label = info.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
                    found[pkg] = TvApp(label, pkg, info.loadIcon(pm))
                }
            }
        apps = found.values.sortedBy { it.label.lowercase() }
    }

    LaunchedEffect(Unit) { loadApps() }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Row(Modifier.fillMaxSize().padding(28.dp)) {
                Column(Modifier.width(190.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("TCL HOME", color = Accent, fontSize = 23.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp, bottom = 24.dp, top = 10.dp))
                    SectionItem("Главная", Icons.Default.Home, selectedSection == "Главная") { selectedSection = it }
                    SectionItem("Приложения", Icons.Default.Apps, selectedSection == "Приложения") { selectedSection = it }
                    SectionItem("Избранное", Icons.Default.Favorite, selectedSection == "Избранное") { selectedSection = it }
                    Spacer(Modifier.weight(1f))
                    SectionItem("Настройки", Icons.Default.Settings, selectedSection == "Настройки") { selectedSection = it }
                }
                Spacer(Modifier.width(28.dp))
                Column(Modifier.fillMaxSize()) {
                    Text(when (selectedSection) {
                        "Приложения" -> "Приложения"
                        "Избранное" -> "Избранное"
                        "Настройки" -> "Настройки лаунчера"
                        else -> "Добро пожаловать"
                    }, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text(when (selectedSection) {
                        "Настройки" -> "Начальная версия • назначение Home зависит от прошивки"
                        else -> "Выберите приложение с помощью пульта телевизора"
                    }, color = Muted, fontSize = 16.sp)
                    Spacer(Modifier.height(28.dp))
                    if (selectedSection == "Настройки") {
                        SettingsPanel()
                    } else {
                        if (apps.isEmpty()) {
                            Text("Приложения не найдены. Попробуйте перезапустить лаунчер.", color = Muted, fontSize = 18.sp)
                        } else {
                            Text(if (selectedSection == "Главная") "Все приложения" else selectedSection, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(18.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(6.dp)) {
                                items(apps, key = { it.packageName }) { app ->
                                    AppCard(app) {
                                        val launch = context.packageManager.getLaunchIntentForPackage(app.packageName)
                                        if (launch != null) context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Text("TCL Home • прототип 0.1.0", color = Color(0xFF777D8C), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun SectionItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: (String) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth().height(54.dp)
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected || focused) Color(0xFF29374D) else Color.Transparent)
            .border(if (focused) 2.dp else 0.dp, if (focused) Accent else Color.Transparent, RoundedCornerShape(14.dp))
            .clickable { onClick(label) }
            .focusable()
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = label, tint = if (selected || focused) Accent else Muted, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, color = if (selected || focused) Color.White else Muted, fontSize = 16.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun AppCard(app: TvApp, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.width(160.dp).height(174.dp)
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(18.dp))
            .background(if (focused) Color(0xFF29374D) else Panel)
            .border(if (focused) 3.dp else 1.dp, if (focused) Accent else Color(0xFF343744), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .focusable()
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        val iconBitmap = remember(app.packageName) { app.icon.toBitmapImage() }
        androidx.compose.foundation.Image(bitmap = iconBitmap, contentDescription = app.label, modifier = Modifier.size(68.dp))
        Spacer(Modifier.height(14.dp))
        Text(app.label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2)
    }
}

@Composable
private fun SettingsPanel() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Этот экран — стартовая версия лаунчера.", color = Color.White, fontSize = 20.sp)
        Text("• Для назначения Home откройте настройки Android TV и выберите приложение, если прошивка показывает такой выбор.", color = Muted, fontSize = 16.sp)
        Text("• Если кнопка Home продолжает открывать Google TV, это может быть ограничением прошивки TCL.", color = Muted, fontSize = 16.sp)
        Text("• Избранное и сохранение настроек пока не реализованы.", color = Muted, fontSize = 16.sp)
    }
}

private fun Drawable.toBitmapImage(): ImageBitmap {
    val width = if (intrinsicWidth > 0) intrinsicWidth else 96
    val height = if (intrinsicHeight > 0) intrinsicHeight else 96
    val bitmap = Bitmap.createBitmap(width.coerceAtMost(256), height.coerceAtMost(256), Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    setBounds(0, 0, canvas.width, canvas.height)
    draw(canvas)
    return bitmap.asImageBitmap()
}

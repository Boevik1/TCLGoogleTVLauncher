# TCL Google TV Launcher (Kotlin)

Starter project for an Android TV home-screen launcher. It is a prototype, not a tested release APK.

## Requirements
- Android Studio with Android SDK Platform 35
- JDK 17
- Internet access for Gradle dependency resolution

## Build
1. Extract the ZIP.
2. Open the `TCLGoogleTVLauncher` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK on the TCL TV, or use `adb install -r app-debug.apk`.

## Make it the Home app
The manifest declares `MAIN + HOME + DEFAULT` and `MAIN + LEANBACK_LAUNCHER`. After installing, press Home and look for a system chooser, or inspect Android TV Settings for the Home-app/default-app setting. The exact options depend on TCL firmware and Google TV version. Some firmware builds keep Google TV bound to the Home key; this project does not bypass firmware restrictions.

## Notes
- `QUERY_ALL_PACKAGES` is used so the launcher can list installed apps. This is appropriate for a sideloaded launcher prototype; distribution policies may require a narrower package visibility design.
- The app list merges TV Leanback activities and standard launcher activities, deduplicated by package.
- Current version is intentionally minimal: favorites persistence, editable tiles, app ordering, wallpapers, and full settings are not yet implemented.
- If Gradle plugin versions are unavailable in your installed Android Studio, update the plugin versions in the root `build.gradle.kts` to versions supported by your setup.
